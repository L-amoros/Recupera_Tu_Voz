import "package:flutter/material.dart";
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import "../models/app_user.dart";
import '../models/app_settings.dart';
import '../models/frase_item.dart';
import '../services/settings_service.dart';
import '../services/tts_service.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';

class FrasesScreen extends StatefulWidget {
  final AppSettings settings;
  final AppUser? user;
  const FrasesScreen({super.key, required this.settings, this.user});

  @override
  State<FrasesScreen> createState() => _FrasesScreenState();
}

class _FrasesScreenState extends State<FrasesScreen> {
  AdaptiveColors get c => AdaptiveColors.of(context);

  late final TtsService _tts;
  final SettingsService _settingsSvc = SettingsService();

  String _categoriaActiva = 'Todas';

  List<FraseItem> _frasesDefault = [];
  List<FraseItem> _frasesPersonales = [];

  bool _loadingDefault = true;

  int? _activeIndex;
  int? _sharingIndex;

  @override
  void initState() {
    super.initState();

    _tts = TtsService();

    _tts.onError = (msg) {
      if (mounted) {
        setState(() => _activeIndex = null);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(msg),
            backgroundColor: c.warn.withValues(alpha: 0.9),
          ),
        );
      }
    };

    _tts.onDone = () {
      if (mounted) setState(() => _activeIndex = null);
    };

    _tts.init();
    _loadFrases();
  }

  // 🔥 PRO: cache + backend + fallback + retry
  Future<void> _loadFrases() async {
    final api = FrasesApiService();

    final cached = await _settingsSvc.loadCachedFrasesDefault();
    final personales = await _settingsSvc.loadFrasesPersonales();

    // 1️⃣ Mostrar cache primero
    if (mounted && cached.isNotEmpty) {
      setState(() {
        _frasesDefault = cached;
        _frasesPersonales = personales;
        _loadingDefault = false;
      });
    }

    // 2️⃣ Backend
    try {
      final defaults = await api.fetchDefault();

      if (mounted) {
        setState(() {
          _frasesDefault = defaults.cast<FraseItem>();
          _frasesPersonales = personales;
          _loadingDefault = false;
        });
      }

      await _settingsSvc.saveCachedFrasesDefault(defaults.cast<FraseItem>());

    } catch (_) {
      // 3️⃣ fallback solo si no había cache
      if (mounted && cached.isEmpty) {
        setState(() => _loadingDefault = false);

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: const Text('Error cargando frases. Modo offline'),
            action: SnackBarAction(
              label: 'Reintentar',
              onPressed: _loadFrases,
            ),
          ),
        );
      }
    }
  }

  List<FraseItem> get _frasesVisibles {
    final todas = [..._frasesDefault, ..._frasesPersonales];

    if (_categoriaActiva == 'Todas') return todas;
    if (_categoriaActiva == 'Mis frases') return _frasesPersonales;

    return todas.where((f) => f.categoria == _categoriaActiva).toList();
  }

  Future<void> _compartirAudio(int index, String texto) async {
    if (widget.user?.token == null || !(widget.user?.hasVoice ?? false)) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Necesitas tener una voz clonada'),
          backgroundColor: Colors.orange,
        ),
      );
      return;
    }

    if (_sharingIndex != null) return;

    setState(() => _sharingIndex = index);

    try {
      final api = VoiceApiService();

      final bytes = await api.synthesize(
        token: widget.user!.token,
        text: texto,
        speed: (widget.settings.velocidad + 0.5).clamp(0.5, 2.0),
      );

      final dir = await getTemporaryDirectory();

      final safeNombre = texto
          .replaceAll(RegExp(r'[^\w\s]'), '')
          .trim()
          .replaceAll(' ', '_')
          .substring(0, texto.length.clamp(0, 30));

      final file = File('${dir.path}/voz_$safeNombre.mp3');

      await file.writeAsBytes(bytes);

      if (!mounted) return;

      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'audio/mpeg')],
        text: texto,
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _sharingIndex = null);
    }
  }

  Future<void> _hablar(int index, String texto) async {
    if (_activeIndex != null) return;

    setState(() => _activeIndex = index);

    final ok = await _tts.speak(
      text: texto,
      settings: widget.settings,
      userToken: widget.user?.token,
      hasVoice: widget.user?.hasVoice ?? false,
    );

    if (!ok && mounted) setState(() => _activeIndex = null);
  }

  @override
  Widget build(BuildContext context) {
    final frases = _frasesVisibles;

    return Scaffold(
      backgroundColor: c.bg,
      appBar: AppBar(title: const Text('Frases rápidas')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: ChipRow(
              options: categoriasAll,
              selected: _categoriaActiva,
              onSelect: (c) => setState(() => _categoriaActiva = c),
              colorOf: AppColors.catColor,
            ),
          ),

          Divider(color: c.border, height: 1),

          Expanded(
            child: _loadingDefault
                ? const Center(child: CircularProgressIndicator())
                : frases.isEmpty
                ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.chat_bubble_outline,
                      color: c.textDim, size: 44),
                  const SizedBox(height: 12),
                  Text('No hay frases en esta categoría',
                      style: TextStyle(
                          color: c.textDim, fontSize: 14)),
                ],
              ),
            )
                : GridView.builder(
              padding: const EdgeInsets.all(14),
              gridDelegate:
              const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                childAspectRatio: 1.65,
              ),
              itemCount: frases.length,
              itemBuilder: (_, i) {
                final frase = frases[i];
                final isActive = _activeIndex == i;
                final isBusy = _activeIndex != null && !isActive;

                return _FraseTile(
                  frase: frase,
                  isActive: isActive,
                  isBusy: isBusy,
                  isSharing: _sharingIndex == i,
                  onTap: () => _hablar(i, frase.texto),
                  onShare: (widget.user?.hasVoice ?? false)
                      ? () => _compartirAudio(i, frase.texto)
                      : null,
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}