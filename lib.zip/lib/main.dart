import 'package:flutter/material.dart';
import 'models/app_settings.dart';
import 'models/app_user.dart';
import 'screens/clone_voice_screen.dart';
import 'screens/frases_screen.dart';
import 'screens/home_screen.dart';
import 'screens/lip_screen.dart';
import 'screens/login_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/register_screen.dart';
import 'screens/text_screen.dart';
import 'services/api_service.dart';
import 'services/settings_service.dart';
import 'theme/app_theme.dart';
import 'screens/app_router.dart';
import 'screens/trabajo_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const RecuperaTuVozApp());
}

class RecuperaTuVozApp extends StatefulWidget {
  const RecuperaTuVozApp({super.key});

  @override
  State<RecuperaTuVozApp> createState() => _RecuperaTuVozAppState();

  static _RecuperaTuVozAppState of(BuildContext context) =>
      context.findAncestorStateOfType<_RecuperaTuVozAppState>()!;
}

class _RecuperaTuVozAppState extends State<RecuperaTuVozApp> {
  ThemeMode _themeMode = ThemeMode.dark;

  void setTheme(bool oscuro) {
    setState(() {
      _themeMode = oscuro ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Recupera tu voz',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      darkTheme: AppTheme.dark,
      themeMode: _themeMode,
      home: const AppRoot(),
    );
  }
}

// ─────────────────────────────────────────
// ROOT APP (LOGIN / SESSION)
// ─────────────────────────────────────────

class AppRoot extends StatefulWidget {
  const AppRoot({super.key});

  @override
  State<AppRoot> createState() => _AppRootState();
}

class _AppRootState extends State<AppRoot> {
  final AuthService _auth = AuthService();
  final SettingsService _settingsSvc = SettingsService();
  final VoiceApiService _voiceApi = VoiceApiService();

  AppUser? _user;
  AppSettings _settings = const AppSettings();
  bool _loading = true;
  bool _showRegister = false;

  @override
  void initState() {
    super.initState();
    _boot();
  }

  Future<void> _boot() async {
    final user = await _auth.loadUser();
    final settings = await _settingsSvc.loadSettings();

    AppUser? syncedUser = user;

    if (user != null && user.token.isNotEmpty) {
      try {
        final status = await _voiceApi.checkVoiceStatusFull(user.token);
        syncedUser = user.copyWith(
          hasVoice: status['has_voice'] ?? user.hasVoice,
          numReferences: status['num_references'] ?? user.numReferences,
        );
        await _auth.saveUser(syncedUser);
      } catch (_) {}
    }

    if (mounted) {
      setState(() {
        _user = syncedUser;
        _settings = settings;
        _loading = false;
      });
    }
  }

  Future<void> _login(String email, String password) async {
    final user = await _auth.login(email: email, password: password);
    await _auth.saveUser(user);
    if (mounted) setState(() => _user = user);
  }

  Future<void> _loginWithGoogle(String idToken) async {
    final user = await _auth.loginWithGoogle(idToken);
    await _auth.saveUser(user);
    if (mounted) setState(() => _user = user);
  }

  Future<void> _register(String name, String email, String password) async {
    final user =
    await _auth.register(name: name, email: email, password: password);
    await _auth.saveUser(user);

    if (mounted) {
      setState(() {
        _user = user;
        _showRegister = false;
      });
    }
  }

  Future<void> _logout() async {
    await _auth.logout();
    if (mounted) setState(() => _user = null);
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_user == null) {
      if (_showRegister) {
        return RegisterScreen(
          onRegister: _register,
          onGoLogin: () => setState(() => _showRegister = false),
        );
      }

      return LoginScreen(
        onLogin: _login,
        onGoogleLogin: _loginWithGoogle,
        onGoRegister: () => setState(() => _showRegister = true),
      );
    }

    return AppRouter(
      user: _user!,
      settings: _settings,
      onSettingsChanged: (s) {
        setState(() => _settings = s);
        RecuperaTuVozApp.of(context).setTheme(s.temaOscuro);
      },
      onUserChanged: (u) async {
        await _auth.saveUser(u);
        if (mounted) setState(() => _user = u);
      },
      onLogout: _logout,
    );
  }
}

// ─────────────────────────────────────────
// APP SHELL (NAVEGACIÓN)
// ─────────────────────────────────────────

class AppShell extends StatefulWidget {
  final AppUser user;
  final AppSettings settings;
  final ValueChanged<AppSettings> onSettingsChanged;
  final ValueChanged<AppUser> onUserChanged;
  final VoidCallback onLogout;

  const AppShell({
    super.key,
    required this.user,
    required this.settings,
    required this.onSettingsChanged,
    required this.onUserChanged,
    required this.onLogout,
  });

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _tabIndex = 0;
  bool _showCloneVoice = false;
  late AppUser _user;

  final VoiceApiService _voiceApi = VoiceApiService();

  @override
  void initState() {
    super.initState();
    _user = widget.user;
  }

  @override
  void didUpdateWidget(AppShell oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Si el padre actualiza el user (p.ej. tras guardar), sincronizamos
    if (oldWidget.user != widget.user) {
      setState(() => _user = widget.user);
    }
  }

  void _updateUser(AppUser updated) {
    setState(() => _user = updated);
    widget.onUserChanged(updated);
  }

  void _goToTab(int i) => setState(() => _tabIndex = i);

  @override
  Widget build(BuildContext context) {
    if (_showCloneVoice) {
      return CloneVoiceScreen(
        token: _user.token,
        alreadyHasVoice: _user.hasVoice,
        initialNumReferences: _user.numReferences,
        onUploadReplace: (files) async {
          final saved = await _voiceApi.uploadReplaceAudios(
            token: _user.token,
            files: files,
          );
          _updateUser(_user.copyWith(hasVoice: true, numReferences: saved));
          return saved;
        },
        onUploadAdd: (files) async {
          final saved = await _voiceApi.uploadAddAudios(
            token: _user.token,
            files: files,
          );
          _updateUser(_user.copyWith(hasVoice: true, numReferences: saved));
          return saved;
        },
        onDelete: () async {
          await _voiceApi.deleteVoice(_user.token);
          _updateUser(_user.copyWith(hasVoice: false, numReferences: 0));
        },
        onDone: () => setState(() => _showCloneVoice = false),
      );
    }

    // ── Las 5 pantallas de navegación ──────────────────────────
    final screens = [
      HomeScreen(onEmpezar: () => _goToTab(1)),
      TextScreen(settings: widget.settings, user: _user),
      FrasesScreen(settings: widget.settings, user: _user),
      TrabajoScreen(user: _user),
      LipScreen(user: _user),
      ProfileScreen(
        settings: widget.settings,
        user: _user,
        onSettingsChanged: widget.onSettingsChanged,
        onCloneVoice: () => setState(() => _showCloneVoice = true),
        onLogout: widget.onLogout,
        onUserChanged: _updateUser,
      ),
    ];

    return Scaffold(
      body: IndexedStack(index: _tabIndex, children: screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tabIndex,
        onTap: _goToTab,
        selectedItemColor: const Color(0xFF1CE7B2),
        unselectedItemColor: const Color(0x61FFFFFF),
        backgroundColor: const Color(0xFF12121F),
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined),
              activeIcon: Icon(Icons.home),
              label: 'Inicio'),
          BottomNavigationBarItem(
              icon: Icon(Icons.keyboard_outlined),
              activeIcon: Icon(Icons.keyboard),
              label: 'Texto'),
          BottomNavigationBarItem(
              icon: Icon(Icons.grid_view_outlined),
              activeIcon: Icon(Icons.grid_view),
              label: 'Frases'),
          BottomNavigationBarItem(
              icon: Icon(Icons.assignment_outlined),
              activeIcon: Icon(Icons.assignment_rounded),
              label: 'Trabajo'),
          BottomNavigationBarItem(
              icon: Icon(Icons.face_outlined),
              activeIcon: Icon(Icons.face),
              label: 'Labios'),
          BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: 'Perfil'),
        ],
      ),
    );
  }
}